using System;
namespace ProyBaseMuestra.Shared.Entity{

    public class Movie{
        public string MovieName{get;set;}
        public string MovieImage{get;set;}
        public string Sinapsis{get;set;}
        public int Score{get;set;}
    }
}
